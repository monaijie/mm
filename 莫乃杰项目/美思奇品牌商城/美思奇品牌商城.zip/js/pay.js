	$(".bank ul li img").click(function(){				
			$(".bank ul li img").removeClass("borders")
			$(this).addClass("borders");
		})		
	