$('.voide img').click(function(){
				$('.voide img').css("display","none");	
				var video = $("#open");
				video[0].play();
			})